What is being displayed is the user image if there is one, then their username, with a link to their profile, then their description and finally below that is the tweet that they sent out.

The right side of the screen has user mentions. This does not follow the tweet though. The mentions actually run at 3.5 seconds instead of 3 just to break the the page up a little bit.

Bottstrap is used to make the page responsive, when the width is smaller than normal the mentions shifts over to the right, below the tweets.